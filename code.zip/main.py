from process_claims import main as process_main


def main():
    process_main()


if __name__ == '__main__':
    main()
