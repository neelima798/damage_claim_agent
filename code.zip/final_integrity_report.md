# Final Integrity Report

- Total claims processed: 44
- Missing image references: 7
- Repaired rows (approx): 40

## Supported claims
- Total supported: 16
- Supported with visual evidence and supporting ids: 16

## Contradicted claims
- Total contradicted: 0
- Validated contradicted (no damage detected): 0

## Not Enough Information
- Total NEI: 10
- Validated NEI (images missing or no damage): 7

## Suspicious cases (sample)
- {'user_id': 'user_034', 'issue': 'nei_but_damage', 'imgs_exist': True, 'damage': True, 'supporting': 'none'}
- {'user_id': 'user_043', 'issue': 'nei_but_damage', 'imgs_exist': True, 'damage': True, 'supporting': 'none'}
- {'user_id': 'user_042', 'issue': 'nei_but_damage', 'imgs_exist': True, 'damage': True, 'supporting': 'none'}

