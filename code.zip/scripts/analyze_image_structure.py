import os, json

base = 'c:/Users/antha/OneDrive/Desktop/damage_claim_agent'
os.chdir(base)

# Find all image files and their locations
all_images = {}
for root, dirs, files in os.walk(base):
    if 'submission_package' in root or '__MACOSX' in root:
        continue
    for f in files:
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, base).replace('\\', '/')
            if f not in all_images:
                all_images[f] = []
            all_images[f].append(rel_path)

# Find which folders exist
folders_with_images = {}
for root, dirs, files in os.walk(base):
    if 'submission_package' in root or '__MACOSX' in root:
        continue
    for f in files:
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            rel_root = os.path.relpath(root, base).replace('\\', '/')
            if rel_root not in folders_with_images:
                folders_with_images[rel_root] = []
            folders_with_images[rel_root].append(f)

# Expected structure analysis
expected_cases = {}
with open('output.csv', newline='', encoding='utf-8') as f:
    import csv
    rows = list(csv.DictReader(f))
    for r in rows:
        ips = [p.strip() for p in r['image_paths'].split(';') if p.strip()]
        for p in ips:
            case_match = None
            for part in p.split('/'):
                if part.startswith('case_'):
                    case_match = part
                    break
            if case_match and case_match not in expected_cases:
                expected_cases[case_match] = []
            if case_match:
                expected_cases[case_match].append(p)

print('=== FOLDERS WITH IMAGES ===')
for folder in sorted(folders_with_images.keys()):
    print(f'{folder}: {len(folders_with_images[folder])} files')
    if len(folders_with_images[folder]) <= 5:
        for f in folders_with_images[folder]:
            print(f'  - {f}')

print('\n=== EXPECTED CASE FOLDERS (from output.csv) ===')
print(f'Total expected cases: {len(expected_cases)}')
print('Sample (first 20):')
for case in sorted(expected_cases.keys())[:20]:
    print(f'  {case}')

print('\n=== IMAGE FILES AVAILABLE ===')
print(f'Total unique image filenames: {len(all_images)}')
print('Sample:')
for fname in sorted(all_images.keys())[:20]:
    locs = all_images[fname]
    print(f'  {fname}:')
    for loc in locs:
        print(f'    - {loc}')

print('\n=== ANALYSIS ===')
# Count how many images exist in images/test folder
images_test_count = 0
for folder in folders_with_images:
    if 'images/test' in folder:
        images_test_count += len(folders_with_images[folder])
print(f'Images in images/test: {images_test_count}')

# Count images in audit_temp
audit_temp_count = 0
for folder in folders_with_images:
    if 'audit_temp' in folder:
        audit_temp_count += len(folders_with_images[folder])
print(f'Images in audit_temp: {audit_temp_count}')

# Count images in other locations
other_count = 0
for folder in folders_with_images:
    if 'images/test' not in folder and 'audit_temp' not in folder:
        other_count += len(folders_with_images[folder])
print(f'Images in other locations: {other_count}')
