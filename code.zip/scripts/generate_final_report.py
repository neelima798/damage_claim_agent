import csv, os, json
from PIL import Image
import numpy as np
import cv2
base=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out=os.path.join(base,'output.csv')
rows=[]
with open(out,newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
missing=[]
repaired_count=0
bak=os.path.join(base,'output.csv.bak')
if os.path.exists(bak):
    repaired_count=0
    with open(bak,newline='',encoding='utf-8') as f:
        old=list(csv.DictReader(f))
    for o,n in zip(old,rows):
        if o['image_paths']!=n['image_paths']:
            repaired_count+=1
supported_total=0
supported_valid=0
contradicted_total=0
contradicted_valid=0
nei_total=0
nei_valid=0
unsupported_issues=[]
for r in rows:
    status=r['claim_status']
    ips=[p.strip() for p in r['image_paths'].split(';') if p.strip()]
    imgs_exist_all=all(os.path.exists(os.path.join(base,p.replace('/','\\'))) for p in ips)
    damage=False
    for p in ips:
        path=os.path.join(base,p.replace('/','\\'))
        if not os.path.exists(path): continue
        try:
            img=Image.open(path).convert('RGB')
            arr=np.array(img)
            gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
            edges=cv2.Canny(gray,50,150)
            ed=edges.sum()/255.0/edges.size
            if ed>0.03:
                damage=True
                break
        except Exception:
            continue
    if status=='supported':
        supported_total+=1
        if imgs_exist_all and damage and r['supporting_image_ids'].lower()!='none':
            supported_valid+=1
        else:
            unsupported_issues.append({'user_id':r['user_id'],'issue':'supported_without_evidence','imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})
    elif status=='contradicted':
        contradicted_total+=1
        if not damage:
            contradicted_valid+=1
        else:
            unsupported_issues.append({'user_id':r['user_id'],'issue':'contradicted_but_damage','imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})
    elif status=='not_enough_information':
        nei_total+=1
        if (not imgs_exist_all) or (not damage):
            nei_valid+=1
        else:
            unsupported_issues.append({'user_id':r['user_id'],'issue':'nei_but_damage','imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})
    for p in ips:
        path=os.path.join(base,p.replace('/','\\'))
        if not os.path.exists(path):
            missing.append({'user_id':r['user_id'],'image_path':p})
rep_path=os.path.join(base,'final_integrity_report.md')
with open(rep_path,'w',encoding='utf-8') as f:
    f.write('# Final Integrity Report\n\n')
    f.write(f'- Total claims processed: {len(rows)}\n')
    f.write(f'- Missing image references: {len(missing)}\n')
    f.write(f'- Repaired rows (approx): {repaired_count}\n')
    f.write('\n## Supported claims\n')
    f.write(f'- Total supported: {supported_total}\n')
    f.write(f'- Supported with visual evidence and supporting ids: {supported_valid}\n')
    f.write('\n## Contradicted claims\n')
    f.write(f'- Total contradicted: {contradicted_total}\n')
    f.write(f'- Validated contradicted (no damage detected): {contradicted_valid}\n')
    f.write('\n## Not Enough Information\n')
    f.write(f'- Total NEI: {nei_total}\n')
    f.write(f'- Validated NEI (images missing or no damage): {nei_valid}\n')
    f.write('\n## Suspicious cases (sample)\n')
    for s in unsupported_issues[:50]:
        f.write(f"- {s}\n")
    f.write('\n')
print('written',rep_path)
print('counts',len(missing),repaired_count,supported_total,supported_valid,contradicted_total,contradicted_valid,nei_total,nei_valid)
