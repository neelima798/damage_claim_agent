import csv,os,random,json
from PIL import Image
import numpy as np
import cv2
base=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out=os.path.join(base,'output.csv')
rows=[]
with open(out,newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
if len(rows)>50:
    sample=random.sample(rows,50)
else:
    sample=rows
fails=[]
for r in sample:
    ips=[p.strip() for p in r['image_paths'].split(';') if p.strip()]
    imgs_exist_all=True
    damage=False
    for p in ips:
        path=os.path.join(base,p.replace('/','\\'))
        if not os.path.exists(path):
            imgs_exist_all=False
            continue
        try:
            img=Image.open(path).convert('RGB')
            arr=np.array(img)
            gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
            edges=cv2.Canny(gray,50,150)
            ed=edges.sum()/255.0/edges.size
            if ed>0.03:
                damage=True
        except Exception:
            imgs_exist_all=False
    if r['claim_status']=='supported' and (not imgs_exist_all or not damage or r['supporting_image_ids'].lower()=='none' or r['supporting_image_ids'].strip()==''):
        fails.append({'user_id':r['user_id'],'imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids'],'image_paths':r['image_paths']})
print(json.dumps({'sample_size':len(sample),'fails_count':len(fails),'fails_sample':fails[:50]},indent=2))
