import csv, os, json
from PIL import Image
import numpy as np
import cv2

base = 'c:/Users/antha/OneDrive/Desktop/damage_claim_agent'
os.chdir(base)

# Step 1: Parse current output.csv and identify missing images
output_csv = 'output.csv'
rows = []
with open(output_csv, newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# Step 2: Build comprehensive missing images report
missing_report = []
for r in rows:
    ips = [p.strip() for p in r['image_paths'].split(';') if p.strip()]
    for p in ips:
        path = os.path.join(base, p.replace('/', '\\'))
        exists = os.path.exists(path)
        claim_obj = r.get('claim_object', 'unknown')
        missing_report.append({
            'user_id': r['user_id'],
            'claim_object': claim_obj,
            'image_path': p,
            'file_exists': 'yes' if exists else 'no',
            'repair_attempted': 'no',
            'repair_successful': 'no'
        })

# Step 3: Search workspace for all image files
image_locations = {}
for root, dirs, files in os.walk(base):
    if 'submission_package' in root or '__MACOSX' in root:
        continue
    for f in files:
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, base).replace('\\', '/')
            if f not in image_locations:
                image_locations[f] = []
            image_locations[f].append({
                'path': rel_path,
                'full_path': full_path,
                'folder': os.path.dirname(rel_path)
            })

# Step 4: Attempt high-confidence repairs
repair_map = {}
for entry in missing_report:
    if entry['file_exists'] == 'yes':
        continue
    
    img_path = entry['image_path']
    filename = os.path.basename(img_path)
    expected_folder = os.path.dirname(img_path).split('/')[-1]  # e.g., 'case_001'
    
    if filename in image_locations:
        candidates = image_locations[filename]
        # High confidence repair: exact filename + correct folder match
        best_match = None
        for cand in candidates:
            cand_folder = cand['path'].split('/')[-2] if '/' in cand['path'] else ''
            if cand_folder.lower() == expected_folder.lower():
                best_match = cand
                break
        
        if best_match:
            # Repair with high confidence
            entry['repair_attempted'] = 'yes'
            entry['repair_successful'] = 'yes'
            repair_map[img_path] = best_match['path']
            entry['image_path'] = best_match['path']
            entry['file_exists'] = 'yes'

# Write missing_images_report.csv
report_csv = 'missing_images_report.csv'
with open(report_csv, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['user_id', 'claim_object', 'image_path', 'file_exists', 'repair_attempted', 'repair_successful'])
    writer.writeheader()
    writer.writerows(missing_report)

print(f'Written {report_csv}')
print(f'Total image references: {len(missing_report)}')
print(f'Missing (file_exists=no): {sum(1 for e in missing_report if e["file_exists"] == "no")}')
print(f'Repairs attempted: {sum(1 for e in missing_report if e["repair_attempted"] == "yes")}')
print(f'Repairs successful: {sum(1 for e in missing_report if e["repair_successful"] == "yes")}')
print(f'\nRepair mapping ({len(repair_map)} items):')
for old, new in list(repair_map.items())[:20]:
    print(f'  {old} -> {new}')

# Write repair mapping to JSON
with open('repair_mapping.json', 'w', encoding='utf-8') as f:
    json.dump(repair_map, f, indent=2)
