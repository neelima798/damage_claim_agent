import csv, os

base = 'c:/Users/antha/OneDrive/Desktop/damage_claim_agent'
os.chdir(base)

# Read output.csv
rows = []
with open('output.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# Existing case folders (only these have images)
existing_cases = {'case_001', 'case_002', 'case_003', 'case_004', 'case_005',
                  'car_broken_004', 'car_crack_003', 'car_dent_001', 'car_scratch_002',
                  'package_water_005'}

# Track downgrades
downgrades = []

# Fix rows
for r in rows:
    if r['claim_status'] != 'supported':
        continue
    
    ips = [p.strip() for p in r['image_paths'].split(';') if p.strip()]
    all_cases_exist = True
    
    for p in ips:
        # Extract case folder from path
        case_found = None
        for part in p.split('/'):
            if part.startswith('case_') or part in existing_cases:
                case_found = part
                break
        
        if case_found not in existing_cases:
            all_cases_exist = False
            break
    
    if not all_cases_exist:
        # Downgrade to contradicted (no evidence available)
        old_status = r['claim_status']
        r['claim_status'] = 'contradicted'
        r['supporting_image_ids'] = 'none'
        downgrades.append({
            'user_id': r['user_id'],
            'claim_object': r.get('claim_object', 'unknown'),
            'old_status': old_status,
            'new_status': 'contradicted',
            'reason': 'image_files_missing_from_dataset',
            'image_paths': r['image_paths']
        })

# Write updated output.csv
with open('output.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

# Write downgrade report
with open('downgrade_report.csv', 'w', newline='', encoding='utf-8') as f:
    if downgrades:
        writer = csv.DictWriter(f, fieldnames=downgrades[0].keys())
        writer.writeheader()
        writer.writerows(downgrades)

print(f'Downgrades: {len(downgrades)}')
print(f'Sample downgrades:')
for d in downgrades[:10]:
    print(f"  {d['user_id']}: {d['old_status']} -> {d['new_status']} ({d['reason']})")
