import csv, os

base = 'c:/Users/antha/OneDrive/Desktop/damage_claim_agent'
os.chdir(base)

# Read output.csv
rows = []
with open('output.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# Existing case folders (only these have images)
existing_cases = {'case_001', 'case_002', 'case_003', 'case_004', 'case_005',
                  'car_broken_004', 'car_crack_003', 'car_dent_001', 'car_scratch_002',
                  'package_water_005'}

# Track path removals
removals = []

# Fix rows - remove image paths for claims referencing non-existent case folders
for r in rows:
    ips = [p.strip() for p in r['image_paths'].split(';') if p.strip()]
    new_ips = []
    
    for p in ips:
        # Extract case folder from path
        case_found = None
        for part in p.split('/'):
            if part.startswith('case_') or part in existing_cases:
                case_found = part
                break
        
        if case_found in existing_cases:
            # Keep this path
            new_ips.append(p)
        else:
            # Remove this path - case doesn't have images
            removals.append({
                'user_id': r['user_id'],
                'removed_path': p,
                'new_status': r['claim_status']
            })
    
    # Update image_paths
    if new_ips:
        r['image_paths'] = ';'.join(new_ips)
    else:
        r['image_paths'] = 'none'
    
    # If status is contradicted/NEI and no images, explicitly set to none
    if r['claim_status'] in ['contradicted', 'not_enough_information']:
        r['image_paths'] = 'none'

# Write updated output.csv
with open('output.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

print(f'Path removals: {len(removals)}')
print(f'Sample removals:')
for r in removals[:10]:
    print(f"  {r['user_id']}: removed {r['removed_path']}")
