import csv,os,json
from PIL import Image
import numpy as np
import cv2
base=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out=os.path.join(base,'output.csv')
rows=[]
with open(out,newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
missing=[]
supported_issues=[]
contradicted_issues=[]
nei_issues=[]
for r in rows:
    img_paths_str=r['image_paths'].strip()
    if img_paths_str.lower()=='none' or img_paths_str=='':
        ips=[]
    else:
        ips=[p.strip() for p in img_paths_str.split(';') if p.strip()]
    imgs_exist_all=True
    damage=False
    for p in ips:
        path=os.path.join(base,p.replace('/','\\'))
        if not os.path.exists(path):
            imgs_exist_all=False
            missing.append({'user_id':r['user_id'],'image_path':p})
            continue
        try:
            img=Image.open(path).convert('RGB')
            arr=np.array(img)
            gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
            edges=cv2.Canny(gray,50,150)
            ed=edges.sum()/255.0/edges.size
            if ed>0.03:
                damage=True
        except Exception:
            imgs_exist_all=False
    status=r['claim_status']
    if status=='supported':
        if (not imgs_exist_all) or (not damage) or (r['supporting_image_ids'].lower()=='none' or r['supporting_image_ids'].strip()=='' ):
            supported_issues.append({'user_id':r['user_id'],'imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})
    elif status=='contradicted':
        if damage:
            contradicted_issues.append({'user_id':r['user_id'],'imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})
    elif status=='not_enough_information':
        if imgs_exist_all and damage:
            nei_issues.append({'user_id':r['user_id'],'imgs_exist':imgs_exist_all,'damage':damage,'supporting':r['supporting_image_ids']})

report={'missing_images_count':len(missing),'missing_images_sample':missing[:50],
        'supported_issues_count':len(supported_issues),'supported_issues_sample':supported_issues[:50],
        'contradicted_issues_count':len(contradicted_issues),'contradicted_issues_sample':contradicted_issues[:50],
        'nei_issues_count':len(nei_issues),'nei_issues_sample':nei_issues[:50]}

# submission requirements
req_files=['output.csv','chat_transcript.txt','evaluation/evaluation_report.md','evaluation/evaluation_metrics.json','final_integrity_report.md','code.zip','submission_package.zip']
missing_req=[f for f in req_files if not os.path.exists(os.path.join(base,f))]
report['missing_submission_files']=missing_req

# overall pass/fail
image_integrity_pass = report['missing_images_count']==0
evidence_validation_pass = report['supported_issues_count']==0 and report['contradicted_issues_count']==0 and report['nei_issues_count']==0
claim_decisions_pass = evidence_validation_pass
submission_requirements_pass = len(missing_req)==0
report['passes']={'image_integrity':image_integrity_pass,'evidence_validation':evidence_validation_pass,'claim_decisions':claim_decisions_pass,'submission_requirements':submission_requirements_pass}

with open(os.path.join(base,'validation_report.json'),'w',encoding='utf-8') as f:
    json.dump(report,f,indent=2)

print(json.dumps(report,indent=2))
