import os
import csv
from PIL import Image
import numpy as np
import cv2
from vision_adapter import analyze_image_with_model


ISSUE_KEYWORDS = {
    'dent': ['dent', 'dented', 'dents'],
    'scratch': ['scratch', 'scratches', 'scraped'],
    'crack': ['crack', 'cracked'],
    'glass_shatter': ['shatter', 'shattered', 'broken glass', 'glass shatter'],
    'broken_part': ['broken', 'broken part', 'broken screen', 'broken hinge'],
    'missing_part': ['missing', 'lost', 'missing part'],
    'torn_packaging': ['torn', 'rip', 'ripped'],
    'crushed_packaging': ['crush', 'crushed', 'smashed'],
    'water_damage': ['water', 'wet', 'soaked', 'water damage'],
    'stain': ['stain', 'stained']
}

PART_KEYWORDS = {
    'car': {
        'front_bumper': ['front bumper', 'front-bumper', 'bumper front'],
        'rear_bumper': ['rear bumper', 'rear-bumper'],
        'door': ['door'],
        'hood': ['hood', 'bonnet'],
        'windshield': ['windshield', 'wind shield', 'windscreen'],
        'side_mirror': ['mirror', 'side mirror'],
        'headlight': ['headlight'],
        'taillight': ['taillight', 'tail light'],
        'fender': ['fender'],
        'quarter_panel': ['quarter panel'],
        'body': ['body']
    },
    'laptop': {
        'screen': ['screen', 'display'],
        'keyboard': ['keyboard', 'keys'],
        'trackpad': ['trackpad', 'touchpad'],
        'hinge': ['hinge'],
        'lid': ['lid'],
        'corner': ['corner'],
        'port': ['port', 'usb', 'hdmi'],
        'base': ['base'],
        'body': ['body']
    },
    'package': {
        'box': ['box'],
        'package_corner': ['corner'],
        'package_side': ['side'],
        'seal': ['seal'],
        'label': ['label'],
        'contents': ['contents', 'inside', 'items'],
        'item': ['item']
    }
}


def parse_issue_from_text(text):
    t = (text or "").lower()
    for issue, kws in ISSUE_KEYWORDS.items():
        for k in kws:
            if k in t:
                return issue
    return 'unknown'


def parse_part_from_text(text, claim_object):
    t = (text or "").lower()
    parts = PART_KEYWORDS.get(claim_object, {})
    for part, kws in parts.items():
        for k in kws:
            if k in t:
                return part
    return 'unknown'


def load_csv_path(base_dir, filenames):
    candidates = [base_dir, os.path.join(base_dir, 'claims'), os.path.join(base_dir, 'dataset')]
    for candidate_root in candidates:
        for name in filenames:
            candidate = os.path.join(candidate_root, name)
            if os.path.exists(candidate):
                return candidate
    return None


def load_user_history(base_dir):
    path = load_csv_path(base_dir, ['user_history.csv'])
    if not path:
        return {}
    history = {}
    with open(path, newline='', encoding='utf-8') as inf:
        reader = csv.DictReader(inf)
        for row in reader:
            history[row.get('user_id', '')] = row
    return history


def load_evidence_requirements(base_dir):
    path = load_csv_path(base_dir, ['evidence_requirements.csv'])
    if not path:
        return []
    requirements = []
    with open(path, newline='', encoding='utf-8') as inf:
        reader = csv.DictReader(inf)
        for row in reader:
            requirements.append({
                'claim_object': row.get('claim_object', '').strip(),
                'applies_to': row.get('applies_to', '').strip(),
                'minimum_image_evidence': row.get('minimum_image_evidence', '').strip(),
                'requirement_id': row.get('requirement_id', '').strip()
            })
    return requirements


def issue_family(issue_type):
    families = {
        'dent': 'dent or scratch',
        'scratch': 'dent or scratch',
        'crack': 'crack',
        'glass_shatter': 'crack',
        'broken_part': 'broken_part',
        'missing_part': 'missing_part',
        'torn_packaging': 'torn_packaging',
        'crushed_packaging': 'crushed_packaging',
        'water_damage': 'water_damage',
        'stain': 'stain'
    }
    return families.get(issue_type, issue_type)


def find_evidence_requirement(issue_type, claim_object, requirements):
    applies = issue_family(issue_type)
    for req in requirements:
        if req['claim_object'] in (claim_object, 'all') and req['applies_to'] == applies:
            return req
    return None


def add_history_risks(user_history):
    flags = set()
    if not user_history:
        return flags
    history_flags = (user_history.get('history_flags') or '').strip()
    if history_flags:
        flags.add('user_history_risk')
    if user_history.get('manual_review_claim', '').strip().lower() not in ('', '0', 'false'):
        flags.add('manual_review_required')
    if user_history.get('rejected_claim', '').strip() not in ('', '0'):
        flags.add('user_history_risk')
    return flags


def resolve_image_path(path, base_dir):
    candidate = os.path.join(base_dir, path)
    if os.path.exists(candidate):
        return candidate
    filename = os.path.basename(path)
    for root, dirs, files in os.walk(base_dir):
        if filename in files:
            return os.path.join(root, filename)
    return candidate


def load_image(path, base_dir):
    try:
        resolved = resolve_image_path(path, base_dir)
        img = Image.open(resolved).convert('RGB')
        return img
    except Exception:
        return None


def find_file_by_name(filename, base_dir):
    """Search workspace for a file with the given filename and return relative path if found."""
    for root, dirs, files in os.walk(base_dir):
        if filename in files:
            full = os.path.join(root, filename)
            # return path relative to base_dir using forward slashes
            return os.path.relpath(full, base_dir).replace('\\', '/')
    return None


def validate_and_repair_paths(image_paths, base_dir):
    """Validate each image path, attempt to repair if missing, and return (repaired_paths, issues).

    issues: list of (user_id, image_path, issue)
    """
    repaired = []
    issues = []
    for p in image_paths:
        p = p.strip()
        if not p:
            continue
        resolved = resolve_image_path(p, base_dir)
        if os.path.exists(resolved):
            # keep original form
            repaired.append(p)
            continue
        # attempt to find by filename elsewhere
        filename = os.path.basename(p)
        found = find_file_by_name(filename, base_dir)
        if found:
            repaired.append(found)
            issues.append({'image_path': p, 'repaired_to': found, 'issue': 'repaired_path'})
        else:
            repaired.append(p)
            issues.append({'image_path': p, 'repaired_to': None, 'issue': 'missing'})
    return repaired, issues


def normalize_text(s):
    if not s:
        return ''
    return s.lower().replace('_', ' ').replace('-', ' ').strip()


def image_path_matches_keywords(path, keywords):
    if not path:
        return False
    text = normalize_text(path)
    return any(k and k in text for k in keywords)


def infer_damage_types_from_metrics(metrics):
    damage_types = set()
    if metrics['contour_count'] > 450 and metrics['edge_density'] > 0.025:
        damage_types.add('crack')
        damage_types.add('broken_part')
    if 0.012 < metrics['edge_density'] <= 0.035 and metrics['contour_count'] > 120:
        damage_types.add('scratch')
    if metrics['edge_density'] < 0.01 and metrics['contrast'] > 20 and metrics['brightness'] > 35:
        damage_types.add('dent')
    if metrics['edge_density'] < 0.02 and metrics['saturation'] < 45 and metrics['brightness'] > 70:
        damage_types.add('water_damage')
    if metrics['contour_count'] > 250 and metrics['edge_density'] > 0.02 and metrics['contrast'] > 40:
        damage_types.add('broken_part')
    return damage_types


def image_quality_and_metrics(img):
    flags = []
    metrics = {}
    try:
        arr = np.array(img)
        gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
        hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
        fm = cv2.Laplacian(gray, cv2.CV_64F).var()
        mean_b = float(gray.mean())
        contrast = float(gray.std())
        edges = cv2.Canny(gray, 50, 150)
        edge_density = float(edges.mean()) / 255.0
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        saturation = float(hsv[:, :, 1].mean())
        aspect_ratio = float(arr.shape[1]) / max(arr.shape[0], 1)

        metrics.update({
            'lap_var': float(fm),
            'brightness': mean_b,
            'contrast': contrast,
            'edge_density': edge_density,
            'contour_count': len(contours),
            'saturation': saturation,
            'aspect_ratio': aspect_ratio,
            'height': arr.shape[0],
            'width': arr.shape[1]
        })

        if fm < 90:
            flags.append('blurry_image')
        if mean_b < 40 or mean_b > 240:
            flags.append('low_light_or_glare')
        if edge_density < 0.005:
            flags.append('cropped_or_obstructed')
        if metrics['aspect_ratio'] > 2.2 or metrics['aspect_ratio'] < 0.45:
            flags.append('wrong_angle')
        if contrast < 15 and edge_density < 0.01:
            flags.append('damage_not_visible')
        if contrast < 20 and saturation < 20 and mean_b > 100:
            flags.append('possible_manipulation')
        return flags, metrics
    except Exception:
        return ['non_original_image'], {}


def image_evidence_summary(image_paths, base_dir, claim_object, object_part, issue_from_text):
    object_keywords = [claim_object] if claim_object else []
    object_keywords.extend(PART_KEYWORDS.get(claim_object, {}).keys())
    object_keywords = [k for k in object_keywords if k]

    visual_issues = set()
    all_flags = set()
    metrics_list = []
    image_ids = []
    image_score = 0.0
    image_count = 0
    object_match = False
    part_match = False

    for path in image_paths:
        path = path.strip()
        if not path:
            continue
        if image_path_matches_keywords(path, [claim_object] + [object_part]):
            object_match = True
        if image_path_matches_keywords(path, [object_part]):
            part_match = True

        resolved_path = resolve_image_path(path, base_dir)
        img = load_image(path, base_dir)
        if img is None:
            all_flags.add('non_original_image')
            continue

        vision_result = analyze_image_with_model(resolved_path, claim_object=claim_object, object_part=object_part, issue_text=issue_from_text)
        if vision_result is not None:
            object_match = object_match or bool(vision_result.get('object_match'))
            part_match = part_match or bool(vision_result.get('part_match'))
            visual_issues.update(vision_result.get('visual_issues', []))
            all_flags.update(vision_result.get('quality_flags', []))
            if vision_result.get('damage_visible'):
                image_score += float(vision_result.get('damage_score', 0.0))
                image_count += 1

        flags, metrics = image_quality_and_metrics(img)
        all_flags.update(flags)
        if metrics:
            detected = infer_damage_types_from_metrics(metrics)
            visual_issues.update(detected)
            metrics_list.append(metrics)
            image_ids.append(os.path.splitext(os.path.basename(path))[0])
            image_score += min(1.0, metrics['edge_density'] * 5 + metrics['contrast'] / 100.0 + len(detected) * 0.15)
            image_count += 1

    damage_visible = image_score / max(image_count, 1) > 0.18
    return {
        'metrics_list': metrics_list,
        'image_ids': image_ids,
        'visual_issues': visual_issues,
        'quality_flags': list(all_flags),
        'damage_visible': damage_visible,
        'object_match': object_match,
        'part_match': part_match,
        'damage_score': image_score / max(image_count, 1) if image_count else 0.0
    }


def evaluate_requirement(requirement, damage_visible, object_match, part_match):
    if not requirement:
        return True, 'no_evidence_requirement'
    minimum = normalize_text(requirement.get('minimum_image_evidence', ''))
    if 'damage visible' in minimum and not damage_visible:
        return False, 'requirement_damage_not_visible'
    if 'object visible' in minimum and not object_match:
        return False, 'requirement_object_not_visible'
    if 'angle' in minimum and not part_match:
        return False, 'requirement_angle_not_verified'
    return True, f"meets_requirement_{requirement.get('requirement_id', 'unknown')}"


def severity_from_score(score):
    if score >= 0.70:
        return 'high'
    if score >= 0.35:
        return 'medium'
    if score > 0:
        return 'low'
    return 'none'


def decide_claim(issue_from_text, metrics_list, quality_flags, images_present, requirement, history_flags, visual_issues, object_match, part_match, damage_visible, damage_score):
    if not images_present:
        return {
            'evidence_standard_met': False,
            'reason': 'images_missing',
            'valid_image': False,
            'claim_status': 'not_enough_information',
            'severity': 'unknown'
        }

    if 'non_original_image' in quality_flags or 'possible_manipulation' in quality_flags:
        return {
            'evidence_standard_met': False,
            'reason': 'possible_image_manipulation',
            'valid_image': False,
            'claim_status': 'not_enough_information',
            'severity': 'unknown'
        }

    # If no object match signal from filename or vision provider but
    # local heuristics detect damage, treat damage as weak evidence for
    # object presence so we don't auto-contradict clear visual damage.
    if not object_match and damage_visible:
        object_match = True

    requirement_met, requirement_reason = evaluate_requirement(requirement, damage_visible, object_match, part_match)
    status = 'not_enough_information'
    reason = requirement_reason
    severity = 'unknown'
    valid_image = True

    if not object_match:
        status = 'contradicted'
        reason = 'wrong_object'
        valid_image = False
    elif issue_from_text == 'unknown':
        status = 'not_enough_information'
        reason = 'text_lacks_damage_description'
        severity = severity_from_score(damage_score)
    else:
        if issue_from_text in visual_issues:
            status = 'supported'
            severity = severity_from_score(damage_score)
            reason = requirement_reason
        elif visual_issues:
            status = 'claim_mismatch'
            reason = 'claim_mismatch'
            severity = severity_from_score(damage_score)
        else:
            status = 'contradicted'
            reason = 'damage_not_visible'
            severity = 'none'
        if not damage_visible:
            if status == 'supported':
                status = 'contradicted'
                reason = 'damage_not_visible'

    if any(flag in quality_flags for flag in ['blurry_image', 'low_light_or_glare', 'cropped_or_obstructed', 'wrong_angle']):
        if status == 'supported':
            status = 'not_enough_information'
            reason = 'image_quality_issues'
            valid_image = False
        elif status == 'contradicted':
            reason = 'image_quality_issues'
            valid_image = False

    evidence_standard_met = status == 'supported' and requirement_met
    if status == 'supported' and not evidence_standard_met:
        reason = requirement_reason

    return {
        'evidence_standard_met': evidence_standard_met,
        'reason': reason,
        'valid_image': valid_image,
        'claim_status': status,
        'severity': severity
    }


def has_text_instructions(text):
    """Detect if text contains instruction-following directives"""
    if not text:
        return False
    text_lower = text.lower()
    instruction_keywords = [
        'approve', 'approve immediately', 'skip', 'skip review',
        'accept', 'accept claim', 'mark as',
        'follow', 'follow this', 'ignore', 'ignore previous',
        'note says', 'the note', 'instruction', 'should be approved'
    ]
    for keyword in instruction_keywords:
        if keyword in text_lower:
            return True
    return False


def process_row(row, base_dir, user_history_index, evidence_requirements):
    user_id = row.get('user_id', '')
    image_paths = row.get('image_paths', '')
    user_claim = row.get('user_claim', '')
    claim_object = row.get('claim_object', '')

    issue_from_text = parse_issue_from_text(user_claim)
    part_from_text = parse_part_from_text(user_claim, claim_object)
    raw_paths = [p.strip() for p in (image_paths or '').split(';') if p.strip()]

    # validate and attempt to repair image paths before analysis
    repaired_paths, path_issues = validate_and_repair_paths(raw_paths, base_dir)
    # update row's image_paths to use repaired paths for downstream processing
    image_paths = ';'.join(repaired_paths)
    row['image_paths'] = image_paths

    evidence = image_evidence_summary(repaired_paths, base_dir, claim_object, part_from_text, issue_from_text)
    quality_flags = set(evidence['quality_flags'])
    present = len(evidence['metrics_list']) > 0

    # Detect text instructions
    if has_text_instructions(user_claim):
        quality_flags.add('text_instruction_present')

    user_history = user_history_index.get(user_id, {})
    history_flags = add_history_risks(user_history)
    quality_flags.update(history_flags)

    requirement = find_evidence_requirement(issue_from_text, claim_object, evidence_requirements)
    decision = decide_claim(
        issue_from_text,
        evidence['metrics_list'],
        list(quality_flags),
        present,
        requirement,
        history_flags,
        evidence['visual_issues'],
        evidence['object_match'],
        evidence['part_match'],
        evidence['damage_visible'],
        evidence['damage_score']
    )

    supporting = []
    # Populate supporting image ids for both supported and claim_mismatch outcomes
    if evidence['metrics_list'] and decision.get('claim_status') in ('supported', 'claim_mismatch'):
        avg = sum(m.get('edge_density', 0) for m in evidence['metrics_list']) / len(evidence['metrics_list'])
        for idx, m in enumerate(evidence['metrics_list']):
            if m.get('edge_density', 0) >= avg * 0.8:
                supporting.append(evidence['image_ids'][idx])

    supporting_val = ';'.join(supporting) if supporting else 'none'

    # Enforce: supported claims must have visual evidence, supporting ids, and analyzed images
    final_claim_status = decision.get('claim_status', 'not_enough_information')
    if final_claim_status == 'supported':
        images_present = len(evidence['metrics_list']) > 0
        if (not images_present) or (supporting_val == 'none') or (not evidence.get('damage_visible', False)):
            # downgrade according to evidence
            if not images_present:
                final_claim_status = 'not_enough_information'
                decision['reason'] = 'images_missing'
                decision['valid_image'] = False
            else:
                final_claim_status = 'contradicted'
                decision['reason'] = 'damage_not_visible'
                decision['valid_image'] = False

    return {
        'user_id': user_id,
        'image_paths': image_paths,
        'user_claim': user_claim,
        'claim_object': claim_object,
        'evidence_standard_met': str(decision.get('evidence_standard_met')).lower(),
        'evidence_standard_met_reason': decision.get('reason', ''),
        'risk_flags': ';'.join(sorted(quality_flags)) if quality_flags else 'none',
        'issue_type': issue_from_text if issue_from_text != 'unknown' else 'unknown',
        'object_part': part_from_text,
        'claim_status': final_claim_status,
        'claim_status_justification': decision.get('reason', ''),
        'supporting_image_ids': supporting_val,
        'valid_image': str(decision.get('valid_image', False)).lower(),
        'severity': decision.get('severity', 'unknown')
    }


def process_csv(input_csv, output_csv, base_dir, user_history_index, evidence_requirements):
    missing_report = []
    with open(input_sample if False else input_csv, newline='', encoding='utf-8') as inf, open(output_csv, 'w', newline='', encoding='utf-8') as outf:
        reader = csv.DictReader(inf)
        fieldnames = ['user_id','image_paths','user_claim','claim_object','evidence_standard_met','evidence_standard_met_reason','risk_flags','issue_type','object_part','claim_status','claim_status_justification','supporting_image_ids','valid_image','severity']
        writer = csv.DictWriter(outf, fieldnames=fieldnames)
        writer.writeheader()
        for row in reader:
            # process_row now repairs paths and returns decision; collect any path issues
            repaired_paths = [p.strip() for p in (row.get('image_paths') or '').split(';') if p.strip()]
            # validate current row paths and detect issues
            _, path_issues = validate_and_repair_paths(repaired_paths, base_dir)
            for it in path_issues:
                missing_report.append({
                    'user_id': row.get('user_id',''),
                    'image_path': it.get('image_path'),
                    'repaired_to': it.get('repaired_to'),
                    'issue': it.get('issue')
                })

            out = process_row(row, base_dir, user_history_index, evidence_requirements)
            writer.writerow(out)
    # write missing images report
    report_path = os.path.join(base_dir, 'missing_images_report.csv')
    if missing_report:
        with open(report_path, 'w', newline='', encoding='utf-8') as r:
            rk = ['user_id','image_path','repaired_to','issue']
            rw = csv.DictWriter(r, fieldnames=rk)
            rw.writeheader()
            for rr in missing_report:
                rw.writerow(rr)
    else:
        # ensure empty report exists
        with open(report_path, 'w', newline='', encoding='utf-8') as r:
            r.write('')

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    claims_dir = os.path.join(base_dir, 'claims')
    dataset_dir = os.path.join(base_dir, 'dataset')
    input_sample = os.path.join(claims_dir, 'sample_claims.csv')
    claims_input = os.path.join(claims_dir, 'claims.csv')
    dataset_input = os.path.join(dataset_dir, 'claims.csv')
    out_sample = os.path.join('evaluation', 'output_sample.csv')
    out_all = os.path.join(claims_dir, 'output.csv')
    root_output = os.path.join(base_dir, 'output.csv')

    os.makedirs('evaluation', exist_ok=True)

    user_history_index = load_user_history(base_dir)
    evidence_requirements = load_evidence_requirements(base_dir)

    if os.path.exists(input_sample):
        print('Processing sample claims...')
        process_csv(input_sample, out_sample, base_dir, user_history_index, evidence_requirements)
        print('Wrote', out_sample)

    if os.path.exists(dataset_input):
        print('Processing dataset claims...')
        process_csv(dataset_input, root_output, base_dir, user_history_index, evidence_requirements)
        print('Wrote', root_output)
    elif os.path.exists(claims_input):
        print('Processing full claims...')
        process_csv(claims_input, out_all, base_dir, user_history_index, evidence_requirements)
        print('Wrote', out_all)


if __name__ == '__main__':
    main()
