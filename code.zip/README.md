Damage Claim Agent

Run the heuristic reviewer over the dataset.

Requirements:
- Python 3.8+
- Pillow, numpy, opencv-python

A faster fallback processor is available in `process_claims_fast.py` when full image analysis is not required.

This version includes stronger image evidence scoring, contradiction detection, object/part validation, risk flag generation, and evidence requirement checking.

Optional multimodal vision adapter:
- Add `vision_adapter.py` to implement a real provider such as Gemini, GPT-4o Vision, Qwen-VL, or Florence.
- Configure with environment variables:
  - `VISION_API_PROVIDER=<provider>`
  - `VISION_API_KEY=<api-key>`
  - `VISION_API_MODEL=<model-name>`
- Use `VISION_API_PROVIDER=mock` for a demo adapter that illustrates how vision results are integrated.
- If no provider is configured, the processor falls back to local image heuristics.

Debug logging for vision responses:
- Set `VISION_DEBUG=1` to enable debug logging of full provider responses.
- Responses are logged to `vision_debug.log` (or set `VISION_DEBUG_FILE=<path>` to change).
- Each log entry contains timestamp, image name, provider name, full response JSON, and any errors.
- Useful for collecting real outputs to refine parsing logic for your specific provider.

Example: using a generic HTTP vision endpoint

Set environment variables (do not paste API keys into code or public logs):

```powershell
set VISION_API_PROVIDER=gemini
set VISION_API_KEY=your_api_key_here
set VISION_API_MODEL=gvg-v1
set VISION_API_URL=https://your-vision-endpoint.example/v1/analyze
```

Simple curl example (replace values):

```bash
curl -X POST "$VISION_API_URL?model=$VISION_API_MODEL" \
  -H "Authorization: Bearer $VISION_API_KEY" \
  -F "image=@/path/to/photo.jpg" \
  -o response.json
```

The `vision_adapter.py` will attempt to parse common JSON structures from the provider. If the provider is not configured or returns unexpected output, the processor will fall back to local heuristics.

Run the core processor:

```bash
pip install -r requirements.txt
python process_claims.py
```

Optional support files:
- `user_history.csv` in the repo root or `claims/` folder
- `evidence_requirements.csv` in the repo root or `claims/` folder

Run the interactive claim agent:

```bash
python claim_agent.py --interactive
```

Or use agent commands directly:

```bash
python claim_agent.py --run sample
python claim_agent.py --run full
python claim_agent.py --explain 2
python claim_agent.py --summary
python claim_agent.py --archive
```

Outputs:
- `claims/output.csv` - predictions for full test set
- `evaluation/output_sample.csv` - predictions for sample set
