import os
import shutil
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
SUB = BASE / 'submission_package'

EXCLUDE_DIRS = {
    '__MACOSX', '.git', '.github', '.venv', 'venv', 'node_modules', '.idea', '.vscode', 'logs', 'audit_temp', 'images', 'claims', 'test'
}

EXCLUDE_FILES = {
    '.DS_Store'
}

EXCLUDE_EXTS = {'.pyc', '.pyo', '.log'}


def should_exclude(path: Path):
    parts = set(p.lower() for p in path.parts)
    if parts & EXCLUDE_DIRS:
        return True
    if path.name in EXCLUDE_FILES:
        return True
    if path.suffix.lower() in EXCLUDE_EXTS:
        return True
    if any(part.endswith('__pycache__') for part in path.parts):
        return True
    return False


def gather_files():
    keep = []
    for root, dirs, files in os.walk(BASE):
        rootp = Path(root)
        # skip submission package if exists
        if SUB in rootp.parents or rootp == SUB:
            continue
        for f in files:
            fp = rootp / f
            rel = fp.relative_to(BASE)
            if should_exclude(rel):
                continue
            # include evaluation assets
            if rel.parts[0] == 'evaluation':
                keep.append(rel)
                continue
            # include essential root files
            if rel.name in (
                'README.md',
                'requirements.txt',
                'main.py',
                'process_claims.py',
                'claim_agent.py',
                'evaluate.py',
                'output.csv',
                'chat_transcript.txt',
                'SUBMISSION_READY.md',
                'PRE_SUBMISSION_AUDIT.md'
            ):
                keep.append(rel)
                continue
            # include dataset claims only
            if rel.parts[0] == 'dataset' and rel.name == 'claims.csv':
                keep.append(rel)
                continue
            # include other root Python scripts
            if fp.suffix == '.py' and len(rel.parts) == 1:
                keep.append(rel)
    return sorted(set(keep))


def build_submission():
    if SUB.exists():
        shutil.rmtree(SUB)
    SUB.mkdir()
    files = gather_files()
    included = []
    removed = []

    all_files = [p.relative_to(BASE) for p in BASE.rglob('*') if p.is_file()]
    for f in all_files:
        if f in files:
            dest = SUB / f
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(BASE / f, dest)
            included.append(str(f))
        else:
            removed.append(str(f))

    # write report
    report = SUB / 'CLEANUP_REPORT.txt'
    with open(report, 'w', encoding='utf-8') as out:
        out.write('Included Files:\n')
        out.write('\n'.join(included))
        out.write('\n\nRemoved Files:\n')
        out.write('\n'.join(removed))

    # zip
    zip_path = BASE / 'submission_package.zip'
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in SUB.rglob('*'):
            z.write(p, p.relative_to(SUB))

    before = sum(p.stat().st_size for p in all_files)
    after = zip_path.stat().st_size

    return {
        'included': included,
        'removed': removed,
        'before_size': before,
        'after_size': after,
        'zip_path': str(zip_path)
    }


if __name__ == '__main__':
    res = build_submission()
    print('Included files:', len(res['included']))
    print('Removed files:', len(res['removed']))
    print('Estimated before size (bytes):', res['before_size'])
    print('ZIP size (bytes):', res['after_size'])
    print('ZIP path:', res['zip_path'])
