#!/usr/bin/env python
"""
Evaluation script for damage claim verification system

This script evaluates the performance of the damage claim processor
against sample predictions and generates metrics.
"""

import os
import csv
import json
import sys
from collections import defaultdict

def load_csv(filepath):
    """Load CSV file and return list of dictionaries"""
    if not os.path.exists(filepath):
        return []
    
    rows = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows


def calculate_metrics(predictions, references=None):
    """Calculate evaluation metrics
    
    Args:
        predictions: List of prediction dicts with 'claim_status' key
        references: List of reference dicts (for comparison), optional
    
    Returns:
        Dict with metrics
    """
    metrics = {
        'total_claims': len(predictions),
        'supported_claims': 0,
        'contradicted_claims': 0,
        'not_enough_info_claims': 0,
        'claims_with_valid_images': 0,
        'average_severity': 'unknown',
        'risk_flags_distribution': defaultdict(int),
        'evidence_standard_met': 0,
    }
    
    severity_counts = defaultdict(int)
    
    for pred in predictions:
        status = pred.get('claim_status', '').lower()
        valid_image = pred.get('valid_image', 'false').lower() == 'true'
        evidence_met = pred.get('evidence_standard_met', 'false').lower() == 'true'
        severity = pred.get('severity', 'unknown').lower()
        risk_flags = pred.get('risk_flags', 'none')
        
        if status == 'supported':
            metrics['supported_claims'] += 1
        elif status == 'contradicted':
            metrics['contradicted_claims'] += 1
        elif status == 'not_enough_information':
            metrics['not_enough_info_claims'] += 1
        
        if valid_image:
            metrics['claims_with_valid_images'] += 1
        
        if evidence_met:
            metrics['evidence_standard_met'] += 1
        
        if severity != 'unknown':
            severity_counts[severity] += 1
        
        # Track risk flags
        if risk_flags and risk_flags != 'none':
            for flag in risk_flags.split(';'):
                flag = flag.strip()
                if flag:
                    metrics['risk_flags_distribution'][flag] += 1
    
    # Calculate percentages
    total = metrics['total_claims']
    if total > 0:
        metrics['supported_pct'] = round(100.0 * metrics['supported_claims'] / total, 1)
        metrics['contradicted_pct'] = round(100.0 * metrics['contradicted_claims'] / total, 1)
        metrics['not_enough_info_pct'] = round(100.0 * metrics['not_enough_info_claims'] / total, 1)
        metrics['valid_images_pct'] = round(100.0 * metrics['claims_with_valid_images'] / total, 1)
        metrics['evidence_met_pct'] = round(100.0 * metrics['evidence_standard_met'] / total, 1)
    
    # Convert defaultdict to regular dict
    metrics['risk_flags_distribution'] = dict(metrics['risk_flags_distribution'])
    
    return metrics


def generate_confusion_matrix(predictions, references):
    """Generate confusion matrix if references available"""
    if not references or len(predictions) != len(references):
        return None
    
    matrix = defaultdict(lambda: defaultdict(int))
    
    for pred, ref in zip(predictions, references):
        pred_status = pred.get('claim_status', 'unknown').lower()
        ref_status = ref.get('claim_status', 'unknown').lower()
        matrix[ref_status][pred_status] += 1
    
    return dict((k, dict(v)) for k, v in matrix.items())


def generate_evaluation_report(output_dir='evaluation'):
    """Generate comprehensive evaluation report"""
    
    print("=" * 60)
    print("DAMAGE CLAIM VERIFICATION - EVALUATION REPORT")
    print("=" * 60)
    print()
    
    # Load predictions
    sample_output = os.path.join(output_dir, 'output_sample.csv')
    test_output = os.path.join(output_dir, 'output_test_with_images.csv')
    
    predictions_sample = load_csv(sample_output)
    predictions_test = load_csv(test_output)
    
    if predictions_sample:
        print("SAMPLE PREDICTIONS EVALUATION")
        print("-" * 60)
        metrics = calculate_metrics(predictions_sample)
        
        print(f"Total Claims: {metrics['total_claims']}")
        print(f"  Supported: {metrics['supported_claims']} ({metrics.get('supported_pct', 0)}%)")
        print(f"  Contradicted: {metrics['contradicted_claims']} ({metrics.get('contradicted_pct', 0)}%)")
        print(f"  Not Enough Information: {metrics['not_enough_info_claims']} ({metrics.get('not_enough_info_pct', 0)}%)")
        print()
        print(f"Image Quality:")
        print(f"  Valid Images: {metrics['claims_with_valid_images']} ({metrics.get('valid_images_pct', 0)}%)")
        print()
        print(f"Evidence Requirements:")
        print(f"  Standard Met: {metrics['evidence_standard_met']} ({metrics.get('evidence_met_pct', 0)}%)")
        print()
        
        if metrics['risk_flags_distribution']:
            print(f"Risk Flags Distribution:")
            for flag, count in sorted(metrics['risk_flags_distribution'].items(), key=lambda x: -x[1]):
                pct = round(100.0 * count / metrics['total_claims'], 1)
                print(f"  {flag}: {count} ({pct}%)")
        print()
    
    if predictions_test:
        print("TEST PREDICTIONS EVALUATION (WITH SYNTHETIC IMAGES)")
        print("-" * 60)
        metrics_test = calculate_metrics(predictions_test)
        
        print(f"Total Claims: {metrics_test['total_claims']}")
        print(f"  Supported: {metrics_test['supported_claims']} ({metrics_test.get('supported_pct', 0)}%)")
        print(f"  Contradicted: {metrics_test['contradicted_claims']} ({metrics_test.get('contradicted_pct', 0)}%)")
        print(f"  Not Enough Information: {metrics_test['not_enough_info_claims']} ({metrics_test.get('not_enough_info_pct', 0)}%)")
        print()
        print(f"Image Quality:")
        print(f"  Valid Images: {metrics_test['claims_with_valid_images']} ({metrics_test.get('valid_images_pct', 0)}%)")
        print()
        print(f"Evidence Requirements:")
        print(f"  Standard Met: {metrics_test['evidence_standard_met']} ({metrics_test.get('evidence_met_pct', 0)}%)")
        print()
        
        if metrics_test['risk_flags_distribution']:
            print(f"Risk Flags Distribution:")
            for flag, count in sorted(metrics_test['risk_flags_distribution'].items(), key=lambda x: -x[1]):
                pct = round(100.0 * count / metrics_test['total_claims'], 1)
                print(f"  {flag}: {count} ({pct}%)")
        print()
    
    # Save metrics to JSON
    report_file = os.path.join(output_dir, 'evaluation_metrics.json')
    if os.path.exists(output_dir):
        metrics_all = {}
        if predictions_sample:
            metrics_all['sample'] = calculate_metrics(predictions_sample)
        if predictions_test:
            metrics_all['test_with_images'] = calculate_metrics(predictions_test)
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(metrics_all, f, indent=2, default=str)
        print(f"Metrics saved to: {report_file}")
    
    print("=" * 60)


def main():
    if len(sys.argv) > 1:
        output_dir = sys.argv[1]
    else:
        output_dir = 'evaluation'
    
    if not os.path.exists(output_dir):
        print(f"Error: Output directory not found: {output_dir}")
        sys.exit(1)
    
    generate_evaluation_report(output_dir)


if __name__ == '__main__':
    main()
