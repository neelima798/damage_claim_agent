#!/usr/bin/env python
"""
Final verification test - run all critical components
"""

import os
import subprocess
import sys

def run_command(cmd, description):
    """Run a command and report results"""
    print(f"\n{'='*60}")
    print(f"TEST: {description}")
    print(f"{'='*60}")
    
    result = subprocess.run(cmd, shell=True, capture_output=False, text=True)
    if result.returncode == 0:
        print(f"✅ {description} - SUCCESS")
        return True
    else:
        print(f"❌ {description} - FAILED")
        return False

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    tests = [
        ("python -m py_compile process_claims.py", "Compile Check: process_claims.py"),
        ("python -m py_compile evaluate.py", "Compile Check: evaluate.py"),
        ("python -m py_compile generate_test_images.py", "Compile Check: generate_test_images.py"),
        ("python -m py_compile test_with_images.py", "Compile Check: test_with_images.py"),
        ("python test_text_instructions_flag.py", "Feature Test: text_instruction_present flag"),
        ("python evaluate.py evaluation", "Framework Test: evaluate.py metrics"),
    ]
    
    passed = 0
    failed = 0
    
    print("\n" + "="*60)
    print("FINAL VERIFICATION TEST SUITE")
    print("="*60)
    
    for cmd, desc in tests:
        if run_command(cmd, desc):
            passed += 1
        else:
            failed += 1
    
    print("\n" + "="*60)
    print("FINAL RESULTS")
    print("="*60)
    print(f"Tests Passed: {passed}/{len(tests)} ✓")
    print(f"Tests Failed: {failed}/{len(tests)}")
    
    if failed == 0:
        print("\n✅ ALL TESTS PASSED - READY FOR SUBMISSION")
        return 0
    else:
        print(f"\n❌ {failed} test(s) failed")
        return 1

if __name__ == '__main__':
    sys.exit(main())
