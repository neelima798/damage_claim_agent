import os
import csv

ISSUE_KEYWORDS = {
    'dent': ['dent', 'dented', 'dents'],
    'scratch': ['scratch', 'scratches', 'scraped'],
    'crack': ['crack', 'cracked'],
    'glass_shatter': ['shatter', 'shattered', 'broken glass', 'glass shatter'],
    'broken_part': ['broken', 'broken part', 'broken screen', 'broken hinge'],
    'missing_part': ['missing', 'lost', 'missing part'],
    'torn_packaging': ['torn', 'rip', 'ripped'],
    'crushed_packaging': ['crush', 'crushed', 'smashed'],
    'water_damage': ['water', 'wet', 'soaked', 'water damage'],
    'stain': ['stain', 'stained']
}

PART_KEYWORDS = {
    'car': ['front bumper','rear bumper','door','hood','windshield','mirror','headlight','taillight','fender','quarter panel','body'],
    'laptop': ['screen','keyboard','trackpad','hinge','lid','corner','port','base','body'],
    'package': ['box','corner','side','seal','label','contents','item']
}


def parse_issue_from_text(text):
    t = (text or "").lower()
    for issue, kws in ISSUE_KEYWORDS.items():
        for k in kws:
            if k in t:
                return issue
    return 'unknown'


def parse_part_from_text(text, claim_object):
    t = (text or "").lower()
    for part in PART_KEYWORDS.get(claim_object, []):
        if part in t:
            return part
    return 'unknown'


def normalize_text(text):
    return (text or '').lower().replace('_', ' ').replace('-', ' ').strip()


def image_path_matches_keywords(path, keywords):
    if not path:
        return False
    text = normalize_text(path)
    return any(k and k in text for k in keywords)


def issue_severity(issue):
    if issue in ('broken_part', 'crack', 'glass_shatter', 'water_damage'):
        return 'high'
    if issue in ('dent', 'missing_part', 'crushed_packaging'):
        return 'medium'
    if issue in ('scratch', 'torn_packaging', 'stain'):
        return 'low'
    return 'unknown'


def process_row(row, base_dir):
    user_id = row.get('user_id','')
    image_paths = row.get('image_paths','')
    user_claim = row.get('user_claim','')
    claim_object = row.get('claim_object','')

    issue = parse_issue_from_text(user_claim)
    part = parse_part_from_text(user_claim, claim_object)

    images = [p.strip() for p in (image_paths or '').split(';') if p.strip()]
    available = [os.path.exists(os.path.join(base_dir, p)) for p in images]
    object_match = any(image_path_matches_keywords(p, [claim_object] + PART_KEYWORDS.get(claim_object, [])) for p in images)
    part_match = part != 'unknown' and any(image_path_matches_keywords(p, [part]) for p in images)
    issue_match = issue != 'unknown' and any(image_path_matches_keywords(p, ISSUE_KEYWORDS.get(issue, [])) for p in images)

    if not images or not any(available):
        evidence_met = 'false'
        reason = 'images_missing_or_unavailable'
        valid_image = 'false'
        claim_status = 'not_enough_information'
        severity = 'unknown'
        risk_flags = 'non_original_image' if images else 'none'
    else:
        valid_image = 'true'
        if not object_match:
            claim_status = 'contradicted'
            reason = 'wrong_object'
            evidence_met = 'false'
            severity = 'unknown'
            risk_flags = 'wrong_object'
        elif issue == 'unknown':
            claim_status = 'not_enough_information'
            reason = 'text_lacks_damage_description'
            evidence_met = 'false'
            severity = 'unknown'
            risk_flags = 'damage_not_visible'
        elif part != 'unknown' and not part_match:
            claim_status = 'contradicted'
            reason = 'wrong_object_part'
            evidence_met = 'false'
            severity = issue_severity(issue)
            risk_flags = 'wrong_object_part'
        elif issue_match:
            claim_status = 'supported'
            reason = 'image_contains_requested_damage_type'
            evidence_met = 'true'
            severity = issue_severity(issue)
            risk_flags = 'none'
        else:
            claim_status = 'contradicted'
            reason = 'damage_not_visible'
            evidence_met = 'false'
            severity = 'none'
            risk_flags = 'damage_not_visible'

    supporting = ';'.join([os.path.splitext(os.path.basename(p))[0] for p, ex in zip(images, available) if ex]) or 'none'

    return {
        'user_id': user_id,
        'image_paths': image_paths,
        'user_claim': user_claim,
        'claim_object': claim_object,
        'evidence_standard_met': evidence_met,
        'evidence_standard_met_reason': reason,
        'risk_flags': risk_flags,
        'issue_type': issue if issue!='unknown' else 'unknown',
        'object_part': part,
        'claim_status': claim_status,
        'claim_status_justification': reason,
        'supporting_image_ids': supporting,
        'valid_image': valid_image,
        'severity': severity
    }


def process_csv(input_csv, output_csv, base_dir):
    with open(input_csv, newline='', encoding='utf-8') as inf, open(output_csv, 'w', newline='', encoding='utf-8') as outf:
        reader = csv.DictReader(inf)
        fieldnames = ['user_id','image_paths','user_claim','claim_object','evidence_standard_met','evidence_standard_met_reason','risk_flags','issue_type','object_part','claim_status','claim_status_justification','supporting_image_ids','valid_image','severity']
        writer = csv.DictWriter(outf, fieldnames=fieldnames)
        writer.writeheader()
        for row in reader:
            out = process_row(row, base_dir)
            writer.writerow(out)


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    claims_dir = os.path.join(base_dir, 'claims')
    input_sample = os.path.join(claims_dir, 'sample_claims.csv')
    input_all = os.path.join(claims_dir, 'claims.csv')
    out_sample = os.path.join('evaluation', 'output_sample_fast.csv')
    out_all = os.path.join(claims_dir, 'output_fast.csv')

    os.makedirs('evaluation', exist_ok=True)

    if os.path.exists(input_sample):
        process_csv(input_sample, out_sample, base_dir)
        print('Wrote', out_sample)
    if os.path.exists(input_all):
        process_csv(input_all, out_all, base_dir)
        print('Wrote', out_all)


if __name__ == '__main__':
    main()
