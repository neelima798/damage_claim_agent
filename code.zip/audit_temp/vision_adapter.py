import os
from typing import Any, Dict, Optional
import json
import datetime

import requests

# Configuration via environment
VISION_API_PROVIDER = os.environ.get('VISION_API_PROVIDER', '').strip().lower()
VISION_API_KEY = os.environ.get('VISION_API_KEY', '').strip()
VISION_API_MODEL = os.environ.get('VISION_API_MODEL', '').strip()
# For generic HTTP-based adapters you can provide a full URL
VISION_API_URL = os.environ.get('VISION_API_URL', '').strip()

# Debug logging configuration
VISION_DEBUG = os.environ.get('VISION_DEBUG', '').strip().lower() in ('1', 'true', 'yes', 'on')
VISION_DEBUG_FILE = os.environ.get('VISION_DEBUG_FILE', 'vision_debug.log').strip()


def has_vision_adapter() -> bool:
    """Return True when an external vision provider is configured."""
    return bool(VISION_API_PROVIDER and VISION_API_KEY)


def is_mock_provider() -> bool:
    """Return True when using the local mock vision adapter."""
    return VISION_API_PROVIDER in ('mock', 'demo', 'local')


def _debug_log_response(image_path: str, provider: str, resp_json: Dict[str, Any], error: Optional[str] = None) -> None:
    """Log provider response to a debug file if VISION_DEBUG is enabled.

    This helps collect real responses to refine parsing logic.
    """
    if not VISION_DEBUG:
        return

    try:
        timestamp = datetime.datetime.now().isoformat()
        log_entry = {
            'timestamp': timestamp,
            'image': os.path.basename(image_path),
            'provider': provider,
            'response': resp_json,
            'error': error
        }
        with open(VISION_DEBUG_FILE, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry) + '\n')
    except Exception:
        # Silent fail on debug logging errors
        pass


def _try_parse_response(resp_json: Dict[str, Any]) -> Dict[str, Any]:
    """Try to extract a minimal standardized result from provider JSON.

    This is tolerant and will look for common keys that providers use.
    """
    result = {
        'visual_issues': [],
        'object_match': False,
        'part_match': False,
        'damage_visible': False,
        'damage_score': 0.0,
        'quality_flags': []
    }
    # Common, simple mappings
    if not isinstance(resp_json, dict):
        return result
    # Provider may return top-level keys
    for k in ('visual_issues', 'labels', 'detections'):
        if k in resp_json and isinstance(resp_json[k], (list, tuple)):
            result['visual_issues'] = [str(x) for x in resp_json[k]]
            break

    if 'damage_visible' in resp_json:
        result['damage_visible'] = bool(resp_json.get('damage_visible'))
    if 'damage_score' in resp_json:
        try:
            result['damage_score'] = float(resp_json.get('damage_score', 0.0))
        except Exception:
            result['damage_score'] = 0.0

    # fallback: structured outputs like {'predictions': [ { 'displayName':..., 'score':... } ]}
    if 'predictions' in resp_json and isinstance(resp_json['predictions'], list):
        labels = []
        score = 0.0
        for pred in resp_json['predictions']:
            if isinstance(pred, dict):
                name = pred.get('displayName') or pred.get('label') or pred.get('name')
                if name:
                    labels.append(str(name))
                s = pred.get('score') or pred.get('confidence') or 0.0
                try:
                    score = max(score, float(s))
                except Exception:
                    pass
        if labels:
            result['visual_issues'] = labels
        if score:
            result['damage_score'] = score

    # quality flags
    if 'quality_flags' in resp_json and isinstance(resp_json['quality_flags'], list):
        result['quality_flags'] = [str(f) for f in resp_json['quality_flags']]

    # object/part heuristics
    if 'object_match' in resp_json:
        result['object_match'] = bool(resp_json.get('object_match'))
    if 'part_match' in resp_json:
        result['part_match'] = bool(resp_json.get('part_match'))

    return result


def _parse_gemini(resp_json: Dict[str, Any]) -> Dict[str, Any]:
    """Parse responses from Gemini-like vision models into our standard schema.

    This function is tolerant and searches common locations for labels, detections,
    and confidence scores used by different Gemini response formats.
    """
    result = {
        'visual_issues': [],
        'object_match': False,
        'part_match': False,
        'damage_visible': False,
        'damage_score': 0.0,
        'quality_flags': []
    }

    if not isinstance(resp_json, dict):
        return result

    # 1) Look for 'candidates' or 'outputs' with textual content
    texts = []
    if 'candidates' in resp_json and isinstance(resp_json['candidates'], list):
        for c in resp_json['candidates']:
            if isinstance(c, dict):
                t = c.get('content') or c.get('text') or c.get('display')
                if t:
                    texts.append(str(t))
    if 'outputs' in resp_json and isinstance(resp_json['outputs'], list):
        for o in resp_json['outputs']:
            if isinstance(o, dict):
                # sometimes outputs contain 'content' or nested 'items'
                t = o.get('content') or o.get('text') or o.get('items')
                if isinstance(t, str):
                    texts.append(t)
                elif isinstance(t, list):
                    for it in t:
                        if isinstance(it, dict):
                            maybe = it.get('text') or it.get('content')
                            if maybe:
                                texts.append(str(maybe))

    # 2) Look for structured 'predictions' or 'annotations' similar to other providers
    labels = []
    if 'predictions' in resp_json and isinstance(resp_json['predictions'], list):
        for p in resp_json['predictions']:
            if isinstance(p, dict):
                name = p.get('displayName') or p.get('label') or p.get('name')
                if name:
                    labels.append(str(name))
                s = p.get('score') or p.get('confidence')
                try:
                    result['damage_score'] = max(result['damage_score'], float(s or 0.0))
                except Exception:
                    pass

    # 3) Object detection shapes
    if 'detections' in resp_json and isinstance(resp_json['detections'], list):
        for d in resp_json['detections']:
            if isinstance(d, dict):
                cls = d.get('class') or d.get('label') or d.get('name')
                if cls:
                    labels.append(str(cls))
                s = d.get('score') or d.get('confidence')
                try:
                    result['damage_score'] = max(result['damage_score'], float(s or 0.0))
                except Exception:
                    pass

    # 4) Heuristic: if any label looks like a damage type, mark damage_visible
    damage_like = set(['crack', 'broken', 'dent', 'scratch', 'water', 'shatter', 'hole'])
    for lab in labels:
        low = lab.lower()
        if any(k in low for k in damage_like):
            result['visual_issues'].append(lab)
            result['damage_visible'] = True

    # 5) If textual outputs contain explicit statements, extract keywords
    for t in texts:
        low = t.lower()
        for k in damage_like:
            if k in low:
                result['visual_issues'].append(k)
                result['damage_visible'] = True
        if 'blurry' in low or 'blur' in low:
            result['quality_flags'].append('blurry_image')
        if 'glare' in low or 'overexposed' in low:
            result['quality_flags'].append('low_light_or_glare')

    # 6) Additional simple mappings
    if 'quality' in resp_json and isinstance(resp_json['quality'], dict):
        q = resp_json['quality']
        if q.get('blur'):
            result['quality_flags'].append('blurry_image')

    # Deduplicate lists
    result['visual_issues'] = list(dict.fromkeys(result['visual_issues']))
    result['quality_flags'] = list(dict.fromkeys(result['quality_flags']))

    # If damage_score still zero, set a small value if damage_visible
    if result['damage_score'] == 0.0 and result['damage_visible']:
        result['damage_score'] = 0.5

    return result


def analyze_image_with_model(image_path: str, claim_object: str = '', object_part: str = '', issue_text: str = '') -> Optional[Dict[str, Any]]:
    """Analyze an image with an external vision model.

    Behavior:
    - If `VISION_API_PROVIDER=mock`, returns a filename-based mock result.
    - If `VISION_API_PROVIDER` is set and `VISION_API_URL` is provided, makes a POST
      request with the image bytes to that URL using `Authorization: Bearer <KEY>`.
    - If no provider configured, returns None (processor falls back to local heuristics).
    """
    if is_mock_provider():
        filename = os.path.basename(image_path).lower()
        object_match = bool(claim_object and claim_object.lower() in filename)
        part_match = bool(object_part and object_part.lower() in filename)
        issue_match = bool(issue_text and issue_text.lower() in filename)

        visual_issues = [issue_text] if issue_match else []
        damage_visible = bool(visual_issues)
        damage_score = 0.65 if issue_match else 0.15

        return {
            'source': 'mock',
            'visual_issues': visual_issues,
            'object_match': object_match,
            'part_match': part_match,
            'damage_visible': damage_visible,
            'damage_score': damage_score,
            'quality_flags': [],
        }

    if not has_vision_adapter():
        return None

    # Support provider-specific defaults (example: Gemini-like endpoints)
    if not VISION_API_URL and VISION_API_PROVIDER == 'gemini':
        # Common Google Generative API pattern (user may override with VISION_API_URL)
        if not VISION_API_MODEL:
            raise RuntimeError('VISION_API_MODEL must be set for Gemini provider')
        VISION_API_URL_TO_USE = f'https://generative.googleapis.com/v1/models/{VISION_API_MODEL}:predict'
    else:
        VISION_API_URL_TO_USE = VISION_API_URL

    if not VISION_API_URL_TO_USE:
        raise RuntimeError('VISION_API_URL must be set for external provider usage')

    headers = {'Authorization': f'Bearer {VISION_API_KEY}'}
    files = {}
    data = {}
    # add helpful prompt/context for vision models
    if claim_object or issue_text or object_part:
        data['prompt'] = json.dumps({
            'claim_object': claim_object,
            'object_part': object_part,
            'issue_text': issue_text
        })

    try:
        with open(image_path, 'rb') as f:
            files['image'] = (os.path.basename(image_path), f, 'application/octet-stream')
            # For Gemini we POST similarly; users must provide a compatible VISION_API_URL
            resp = requests.post(VISION_API_URL_TO_USE, headers=headers, data=data, files=files, timeout=60)
        resp.raise_for_status()
        # Some providers return JSON directly; some nest results
        try:
            resp_json = resp.json()
        except Exception:
            # Non-JSON response
            _debug_log_response(image_path, VISION_API_PROVIDER, {}, 'non_json_response')
            return {
                'source': VISION_API_PROVIDER,
                'visual_issues': [],
                'object_match': False,
                'part_match': False,
                'damage_visible': False,
                'damage_score': 0.0,
                'quality_flags': ['vision_api_non_json_response']
            }
        _debug_log_response(image_path, VISION_API_PROVIDER, resp_json)
        if VISION_API_PROVIDER == 'gemini':
            parsed = _parse_gemini(resp_json)
        else:
            parsed = _try_parse_response(resp_json)
        parsed['source'] = VISION_API_PROVIDER
        return parsed
    except requests.RequestException as e:
        # network / auth issues - surface as quality flag so decision logic can handle it
        _debug_log_response(image_path, VISION_API_PROVIDER, {}, f'request_error: {str(e)}')
        return {
            'source': VISION_API_PROVIDER,
            'visual_issues': [],
            'object_match': False,
            'part_match': False,
            'damage_visible': False,
            'damage_score': 0.0,
            'quality_flags': ['vision_api_error']
        }
