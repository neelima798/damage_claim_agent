"""Integration test harness for the vision adapter and claim explanation.

By default this script uses the mock adapter. To test a real provider, set
`VISION_API_PROVIDER`, `VISION_API_KEY`, `VISION_API_MODEL`, and optionally
`VISION_API_URL` in your environment before running.

Usage:
  python integration_test.py --claim 1
  python integration_test.py --claim 2 --use-real
"""
import os
import argparse
import json
import importlib

parser = argparse.ArgumentParser()
parser.add_argument('--claim', type=int, default=1, help='Claim row number (1-based) from sample_claims.csv')
parser.add_argument('--use-real', action='store_true', help='Use configured external vision provider instead of mock')
args = parser.parse_args()

# Set mock provider by default if not using real
if not args.use_real:
    os.environ['VISION_API_PROVIDER'] = 'mock'
# Ensure modules pick up env vars at import-time
# Reload vision_adapter, process_claims, and claim_agent after setting env
import vision_adapter
importlib.reload(vision_adapter)

import process_claims
importlib.reload(process_claims)

import claim_agent
importlib.reload(claim_agent)

agent = claim_agent.ClaimAgent()
try:
    row, result = agent.explain_claim(args.claim, use_full=False)
    print('Claim row:')
    print(json.dumps(row, indent=2))
    print('\nResult:')
    print(json.dumps(result, indent=2))
except Exception as e:
    print('Error running integration test:', str(e))
    raise
