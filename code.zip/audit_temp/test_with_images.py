#!/usr/bin/env python
"""
Test the damage claim processor with synthetic test images
"""

import os
import csv
import sys

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from process_claims import process_csv, load_user_history, load_evidence_requirements

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    claims_dir = os.path.join(base_dir, 'claims')
    
    input_test = os.path.join(claims_dir, 'test_claims.csv')
    output_test = os.path.join(base_dir, 'evaluation', 'output_test_with_images.csv')
    
    os.makedirs(os.path.dirname(output_test), exist_ok=True)
    
    user_history_index = load_user_history(base_dir)
    evidence_requirements = load_evidence_requirements(base_dir)
    
    if os.path.exists(input_test):
        print('Processing test claims with synthetic images...')
        print(f'Input: {input_test}')
        print(f'Output: {output_test}')
        print()
        
        process_csv(input_test, output_test, base_dir, user_history_index, evidence_requirements)
        
        # Display results
        print('\n=== RESULTS ===\n')
        with open(output_test, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader, 1):
                print(f"Claim {i}: {row['user_id']}")
                print(f"  Object: {row['claim_object']}")
                print(f"  Issue: {row['issue_type']}")
                print(f"  Status: {row['claim_status']}")
                print(f"  Valid Image: {row['valid_image']}")
                print(f"  Risk Flags: {row['risk_flags']}")
                print(f"  Severity: {row['severity']}")
                print(f"  Reason: {row['evidence_standard_met_reason']}")
                print()
        
        print(f"✓ Wrote {output_test}")
    else:
        print(f"❌ Test file not found: {input_test}")
        sys.exit(1)

if __name__ == '__main__':
    main()
