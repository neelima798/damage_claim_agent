"""
Generate synthetic test images for damage claim verification
"""

import os
import numpy as np
from PIL import Image, ImageDraw

def create_synthetic_images():
    """Create synthetic test images with different damage patterns"""
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    image_dir = os.path.join(base_dir, 'images', 'test')
    
    # Define test cases with damage patterns
    # Note: Directory names and image paths include object type to enable path-based object detection
    test_cases = {
        'car_dent_001': {
            'description': 'Front bumper with dent',
            'damage_type': 'dent',
            'color': (100, 100, 150),  # Blue car
            'pattern': 'dent',
            'object_type': 'car'
        },
        'car_scratch_002': {
            'description': 'Scratch on bumper',
            'damage_type': 'scratch',
            'color': (200, 50, 50),  # Red car
            'pattern': 'scratch',
            'object_type': 'car'
        },
        'car_crack_003': {
            'description': 'Crack on windshield',
            'damage_type': 'crack',
            'color': (180, 180, 200),  # Windshield
            'pattern': 'crack',
            'object_type': 'car'
        },
        'car_broken_004': {
            'description': 'Broken mirror',
            'damage_type': 'broken_part',
            'color': (100, 100, 100),  # Dark mirror
            'pattern': 'broken',
            'object_type': 'car'
        },
        'package_water_005': {
            'description': 'Water damage on box',
            'damage_type': 'water_damage',
            'color': (200, 180, 140),  # Cardboard
            'pattern': 'water',
            'object_type': 'package'
        }
    }
    
    # Create images for each test case (2 images per case)
    for case_id, config in test_cases.items():
        case_dir = os.path.join(image_dir, case_id)
        os.makedirs(case_dir, exist_ok=True)
        
        # Create full view image with better naming
        img1 = create_damage_image(
            size=(400, 300),
            base_color=config['color'],
            damage_type=config['pattern'],
            is_fullview=True
        )
        # Include object type in filename for path-based detection
        img1.save(os.path.join(case_dir, f"{config['object_type']}_fullview.jpg"), quality=85)
        
        # Create close-up view image with better naming
        img2 = create_damage_image(
            size=(300, 300),
            base_color=config['color'],
            damage_type=config['pattern'],
            is_fullview=False
        )
        # Include object type in filename for path-based detection
        img2.save(os.path.join(case_dir, f"{config['object_type']}_closeup.jpg"), quality=85)
        
        print(f"Created {case_id}: {config['description']}")


def create_damage_image(size, base_color, damage_type, is_fullview):
    """Create a single damage image"""
    
    width, height = size
    
    # Create base image
    img_array = np.ones((height, width, 3), dtype=np.uint8)
    img_array[:, :] = np.array(base_color, dtype=np.uint8)
    
    # Add realistic texture
    noise = np.random.normal(0, 5, (height, width, 3)).astype(np.uint8)
    img_array = np.clip(img_array.astype(int) + noise.astype(int), 0, 255).astype(np.uint8)
    
    img = Image.fromarray(img_array)
    draw = ImageDraw.Draw(img, 'RGBA')
    
    # Add damage patterns
    if damage_type == 'dent':
        # Draw dent as shadow effect
        if is_fullview:
            draw.ellipse([50, 80, 200, 180], fill=(50, 50, 70, 180), outline=(30, 30, 50, 200))
            draw.text((20, 20), "Dent (full view)", fill=(255, 255, 255, 255))
        else:
            draw.ellipse([30, 50, 270, 250], fill=(40, 40, 60, 200), outline=(20, 20, 40, 200))
            draw.text((10, 10), "Dent (close-up)", fill=(255, 255, 255, 255))
    
    elif damage_type == 'scratch':
        # Draw scratch as lines
        if is_fullview:
            for i in range(5):
                draw.line([(80, 100+i*5), (220, 120+i*5)], fill=(0, 0, 0, 200), width=2)
            draw.text((20, 20), "Scratch (full view)", fill=(255, 255, 255, 255))
        else:
            for i in range(8):
                draw.line([(60, 80+i*20), (240, 100+i*20)], fill=(0, 0, 0, 255), width=3)
            draw.text((10, 10), "Scratch (close-up)", fill=(255, 255, 255, 255))
    
    elif damage_type == 'crack':
        # Draw crack as zigzag line
        if is_fullview:
            points = [(100, 50), (150, 100), (140, 150), (180, 200), (200, 250)]
            for i in range(len(points)-1):
                draw.line([points[i], points[i+1]], fill=(0, 0, 0, 220), width=3)
            draw.text((20, 20), "Crack (full view)", fill=(255, 255, 255, 255))
        else:
            points = [(50, 30), (100, 80), (90, 150), (140, 200), (170, 270)]
            for i in range(len(points)-1):
                draw.line([points[i], points[i+1]], fill=(0, 0, 0, 255), width=4)
            draw.text((10, 10), "Crack (close-up)", fill=(255, 255, 255, 255))
    
    elif damage_type == 'broken':
        # Draw broken part
        if is_fullview:
            draw.rectangle([60, 80, 180, 180], outline=(255, 0, 0, 200), width=3)
            draw.line([(60, 80), (180, 180)], fill=(255, 0, 0, 200), width=2)
            draw.line([(180, 80), (60, 180)], fill=(255, 0, 0, 200), width=2)
            draw.text((20, 20), "Broken (full view)", fill=(255, 255, 255, 255))
        else:
            draw.rectangle([40, 60, 260, 260], outline=(255, 0, 0, 255), width=4)
            draw.line([(40, 60), (260, 260)], fill=(255, 0, 0, 255), width=3)
            draw.line([(260, 60), (40, 260)], fill=(255, 0, 0, 255), width=3)
            draw.text((10, 10), "Broken (close-up)", fill=(255, 255, 255, 255))
    
    elif damage_type == 'water':
        # Draw water damage as blotches
        if is_fullview:
            for _ in range(5):
                x = np.random.randint(80, 320)
                y = np.random.randint(80, 220)
                draw.ellipse([x-30, y-30, x+30, y+30], fill=(100, 120, 140, 150))
            draw.text((20, 20), "Water (full view)", fill=(255, 255, 255, 255))
        else:
            for _ in range(8):
                x = np.random.randint(60, 240)
                y = np.random.randint(60, 240)
                draw.ellipse([x-40, y-40, x+40, y+40], fill=(80, 100, 120, 180))
            draw.text((10, 10), "Water (close-up)", fill=(255, 255, 255, 255))
    
    return img.convert('RGB')


if __name__ == '__main__':
    create_synthetic_images()
    print("Synthetic test images created successfully!")
