import os
import csv
import argparse
import sys
import zipfile
from process_claims import process_row, process_csv, load_user_history, load_evidence_requirements

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLAIMS_DIR = os.path.join(BASE_DIR, 'claims')
SAMPLE_INPUT = os.path.join(CLAIMS_DIR, 'sample_claims.csv')
FULL_INPUT = os.path.join(CLAIMS_DIR, 'claims.csv')
SAMPLE_OUTPUT = os.path.join(BASE_DIR, 'evaluation', 'output_sample.csv')
FULL_OUTPUT = os.path.join(CLAIMS_DIR, 'output.csv')


class ClaimAgent:
    def __init__(self):
        self.base_dir = BASE_DIR
        self.claims_dir = CLAIMS_DIR
        self.user_history_index = load_user_history(BASE_DIR)
        self.evidence_requirements = load_evidence_requirements(BASE_DIR)

    def run_sample(self):
        if not os.path.exists(SAMPLE_INPUT):
            raise FileNotFoundError(f'sample input not found: {SAMPLE_INPUT}')
        os.makedirs(os.path.join(BASE_DIR, 'evaluation'), exist_ok=True)
        process_csv(SAMPLE_INPUT, SAMPLE_OUTPUT, BASE_DIR, self.user_history_index, self.evidence_requirements)
        return SAMPLE_OUTPUT

    def run_full(self):
        if not os.path.exists(FULL_INPUT):
            raise FileNotFoundError(f'full input not found: {FULL_INPUT}')
        process_csv(FULL_INPUT, FULL_OUTPUT, BASE_DIR, self.user_history_index, self.evidence_requirements)
        return FULL_OUTPUT

    def explain_claim(self, claim_index, use_full=False):
        input_path = FULL_INPUT if use_full else SAMPLE_INPUT
        output_path = FULL_OUTPUT if use_full else SAMPLE_OUTPUT
        if not os.path.exists(input_path):
            raise FileNotFoundError(f'input not found: {input_path}')
        rows = self._load_rows(input_path)
        if claim_index < 1 or claim_index > len(rows):
            raise IndexError(f'claim index {claim_index} out of range (1-{len(rows)})')
        row = rows[claim_index - 1]
        result = process_row(row, BASE_DIR, self.user_history_index, self.evidence_requirements)
        return row, result

    def summary(self):
        paths = [SAMPLE_INPUT, FULL_INPUT, SAMPLE_OUTPUT, FULL_OUTPUT]
        info = {}
        for path in paths:
            info[os.path.basename(path)] = os.path.exists(path)
        info['sample_rows'] = self._count_rows(SAMPLE_INPUT)
        info['full_rows'] = self._count_rows(FULL_INPUT)
        return info

    def build_archive(self, archive_path=None):
        archive_path = archive_path or os.path.join(BASE_DIR, 'code.zip')
        files = [
            'process_claims.py',
            'process_claims_fast.py',
            'README.md',
            'requirements.txt',
            os.path.join('evaluation', 'evaluation_report.md'),
            os.path.join('evaluation', 'output_sample.csv'),
            os.path.join('claims', 'output.csv'),
            'chat_transcript.txt',
            'claim_agent.py'
        ]
        with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for rel in files:
                full = os.path.join(BASE_DIR, rel)
                if os.path.exists(full):
                    z.write(full, arcname=rel)
        return archive_path

    def interactive(self):
        print('Claim Agent interactive mode. Type help for commands.')
        while True:
            try:
                text = input('> ').strip()
            except EOFError:
                break
            if not text:
                continue
            if text in ('q', 'quit', 'exit'):
                break
            if text in ('help', '?'):
                print(self._help_text())
                continue
            try:
                self._handle_command(text)
            except Exception as e:
                print('Error:', e)

    def _handle_command(self, text):
        parts = text.split()
        cmd = parts[0].lower()
        if cmd == 'run':
            target = parts[1] if len(parts) > 1 else 'sample'
            if target == 'sample':
                out = self.run_sample()
                print('Wrote', out)
            elif target == 'full':
                out = self.run_full()
                print('Wrote', out)
            else:
                print('Unknown run target:', target)
        elif cmd == 'explain':
            if len(parts) < 2:
                print('Usage: explain <n> [full]')
                return
            index = int(parts[1])
            use_full = len(parts) > 2 and parts[2].lower() == 'full'
            row, result = self.explain_claim(index, use_full=use_full)
            print('Claim:', row)
            print('Result:', result)
        elif cmd == 'summary':
            info = self.summary()
            for k, v in info.items():
                print(f'{k}: {v}')
        elif cmd == 'archive':
            path = self.build_archive()
            print('Built archive at', path)
        else:
            print('Unknown command:', cmd)

    def _help_text(self):
        return (
            'Commands:\n'
            '  run sample         - process sample_claims.csv\n'
            '  run full           - process claims.csv\n'
            '  explain <n> [full] - explain claim number n from sample or full dataset\n'
            '  summary            - show dataset/output file status\n'
            '  archive            - build code.zip package\n'
            '  quit               - exit\n'
        )

    def _load_rows(self, path):
        with open(path, newline='', encoding='utf-8') as inf:
            return list(csv.DictReader(inf))

    def _count_rows(self, path):
        if not os.path.exists(path):
            return 0
        with open(path, newline='', encoding='utf-8') as inf:
            return sum(1 for _ in csv.reader(inf)) - 1


def main():
    parser = argparse.ArgumentParser(description='Claim Agent CLI')
    parser.add_argument('--run', choices=['sample', 'full'], help='Run processing pipeline')
    parser.add_argument('--explain', type=int, help='Explain a claim by row number')
    parser.add_argument('--full', action='store_true', help='Use the full claims dataset for explain')
    parser.add_argument('--summary', action='store_true', help='Show data and output summary')
    parser.add_argument('--archive', action='store_true', help='Build code.zip archive')
    parser.add_argument('--interactive', action='store_true', help='Start agent interactive shell')
    args = parser.parse_args()

    agent = ClaimAgent()
    if args.run:
        out = agent.run_sample() if args.run == 'sample' else agent.run_full()
        print('Wrote', out)
        return
    if args.explain is not None:
        row, result = agent.explain_claim(args.explain, use_full=args.full)
        print('Claim:', row)
        print('Result:', result)
        return
    if args.summary:
        info = agent.summary()
        for k, v in info.items():
            print(f'{k}: {v}')
        return
    if args.archive:
        path = agent.build_archive()
        print('Built archive at', path)
        return
    if args.interactive or len(sys.argv) == 1:
        agent.interactive()


if __name__ == '__main__':
    import sys
    main()
