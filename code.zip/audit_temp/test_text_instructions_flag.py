#!/usr/bin/env python
"""
Test text instruction detection
"""

import os
import sys
import csv

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from process_claims import process_csv, load_user_history, load_evidence_requirements

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    claims_dir = os.path.join(base_dir, 'claims')
    
    input_test = os.path.join(claims_dir, 'test_text_instructions.csv')
    output_test = os.path.join(base_dir, 'evaluation', 'output_text_instructions.csv')
    
    os.makedirs(os.path.dirname(output_test), exist_ok=True)
    
    user_history_index = load_user_history(base_dir)
    evidence_requirements = load_evidence_requirements(base_dir)
    
    if os.path.exists(input_test):
        print('Testing text instruction detection...')
        process_csv(input_test, output_test, base_dir, user_history_index, evidence_requirements)
        
        print('\n=== TEXT INSTRUCTION TEST RESULTS ===\n')
        with open(output_test, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader, 1):
                claim_text = row['user_claim'][:50] + "..."
                risk_flags = row['risk_flags']
                has_instruction_flag = 'text_instruction_present' in risk_flags
                print(f"Claim {i}:")
                print(f"  Text: {claim_text}")
                print(f"  Risk Flags: {risk_flags}")
                print(f"  Has text_instruction_present: {has_instruction_flag}")
                print()
        
        print(f"✓ Results written to {output_test}")
    else:
        print(f"❌ Test file not found: {input_test}")
        sys.exit(1)

if __name__ == '__main__':
    main()
